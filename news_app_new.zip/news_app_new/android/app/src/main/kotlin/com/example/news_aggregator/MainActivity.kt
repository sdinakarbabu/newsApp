package com.example.news_aggregator

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

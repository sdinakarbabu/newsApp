import Flutter
import UIKit
import XCTest
@testable import Runner

class RunnerTests: XCTestCase {
    func testAppLaunches() {
        let app = XCUIApplication()
        app.launch()
    }
}
